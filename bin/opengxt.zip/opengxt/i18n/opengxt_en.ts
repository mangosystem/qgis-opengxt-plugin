<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>OpenGXT</name>
    <message>
        <source>OpenGXT - UN GeoAnalysis</source>
        <translation>OpenGXT - UN GeoAnalysis</translation>
    </message>
    <message>
        <source>Vector</source>
        <translation>Vector</translation>
    </message>
    <message>
        <source>Raster</source>
        <translation>Raster</translation>
    </message>
    <message>
        <source>Spatial Statistics</source>
        <translation>Spatial Statistics</translation>
    </message>
</context>
<context>
    <name>PolygonToPoint</name>
    <message>
        <source>Vector</source>
        <translation>Vector</translation>
    </message>
    <message>
        <source>Polygon To Point</source>
        <translation>Polygon To Point</translation>
    </message>
</context>
</TS>
