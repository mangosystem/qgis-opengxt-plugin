<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>OpenGXT</name>
    <message>
        <source>OpenGXT - UN GeoAnalysis</source>
        <translation>OpenGXT - UN GeoAnalysis</translation>
    </message>
    <message>
        <source>Vector</source>
        <translation>Vector</translation>
    </message>
    <message>
        <source>Raster</source>
        <translation>Raster</translation>
    </message>
    <message>
        <source>Spatial Statistics</source>
        <translation>Spatial Statistics</translation>
    </message>
</context>
<context>
    <name>PolygonToPoint</name>
    <message>
        <source>Polygon To Point</source>
        <translation>Polygon To Point</translation>
    </message>
    <message>
        <source>Converts polygon feature layer to point features.</source>
        <translation>Converts polygon feature layer to point features.</translation>
    </message>
    <message>
        <source>Input Polygon Layer</source>
        <translation>Input Polygon Layer</translation>
    </message>
    <message>
        <source>Point on Surface</source>
        <translation>Point on Surface</translation>
    </message>
    <message>
        <source>Output Points</source>
        <translation>Output Points</translation>
    </message>
</context>
</TS>
