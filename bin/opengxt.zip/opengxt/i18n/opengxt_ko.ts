<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ko">
<context>
    <name>OpenGXT</name>
    <message>
        <source>OpenGXT - UN GeoAnalysis</source>
        <translation>OpenGXT - UN GeoAnalysis</translation>
    </message>
    <message>
        <source>Vector</source>
        <translation>벡터 분석</translation>
    </message>
    <message>
        <source>Raster</source>
        <translation>래스터 분석</translation>
    </message>
    <message>
        <source>Spatial Statistics</source>
        <translation>공간 통계</translation>
    </message>
</context>
<context>
    <name>PolygonToPoint</name>
    <message>
        <source>Polygon To Point</source>
        <translation>폴리곤을 포인트로 변환</translation>
    </message>
    <message>
        <source>Converts polygon feature layer to point features.</source>
        <translation>폴리곤 객체를 포인트(중심점, 폴리곤 내 포함) 객체로 변환합니다.</translation>
    </message>
    <message>
        <source>Input Polygon Layer</source>
        <translation>입력 폴리곤 레이어</translation>
    </message>
    <message>
        <source>Point on Surface</source>
        <translation>폴리곤 내에 포함</translation>
    </message>
    <message>
        <source>Output Points</source>
        <translation>출력 포인트</translation>
    </message>
</context>
</TS>
